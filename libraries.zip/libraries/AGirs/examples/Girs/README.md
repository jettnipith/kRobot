# Girs

The files in this directory builds either GirsLite or a "fatter" version, depending
upon the file `config.h`. Per default, C preprocessor symbols are used to select
either GirsLite or the fatter version, depending on the board related CPP symbols.
