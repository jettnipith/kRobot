# Opponator

This is a demo program for translating IR -> Serial.

As the name suggests, it operates an Oppo Bluray/DVD player. It receives an IR signal, and
sends a command to the RS232 serial port.

Since this is just a demo, only very few commands are implemented. It is believed to work
with all present and past Oppos with serial port.
