The files in this directory describes how things ARE, if the user selected to
include a particular file.
Therefore, there may be conditionals depending on hardware specifics, but not
user properties.
