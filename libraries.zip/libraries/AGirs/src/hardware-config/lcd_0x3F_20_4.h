#pragma once

#define LCD_I2C_ADDRESS 0x3F
#define LCD_WIDTH 20
#define LCD_HEIGHT 4
