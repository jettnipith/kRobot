The include files here should not be considered as a public interface to GirsLib.
According to the [Arduino Library Specification 1.5](https://github.com/arduino/Arduino/wiki/Arduino-IDE-1.5:-Library-specification),
only include files (*.h) residing in the `src` are to be considered as exported,
and the ones in subdirectories (like this one) are considered internal ("private").
