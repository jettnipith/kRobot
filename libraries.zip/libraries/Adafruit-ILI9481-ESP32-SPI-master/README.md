# Adafruit-ILI9481-ESP32-SPI

Based on Adafruit_ILI9486_STM32 lib: https://github.com/stevstrong/Adafruit_ILI9486_STM32

modified to support ESP32 by IOXhop (www.ioxhop.com)

## Schematic

![](https://cz.lnwfile.com/li2e42.png)

**Note:** 74HC595 use 5V for VCC
