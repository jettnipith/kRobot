#define _sw 15
int sw1(){
  pinMode(_sw,INPUT);
  return digitalRead(_sw);
}
int SW1(){
  pinMode(_sw,INPUT);
  return digitalRead(_sw);
}
int sw_ok(){
  pinMode(_sw,INPUT);
  return digitalRead(_sw);
}
